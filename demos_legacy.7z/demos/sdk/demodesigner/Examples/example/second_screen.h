#ifndef _second_screen_H_

#include "vtft.h"

void second_screen_show(vtft_t *vtft);

#endif // !_second_screen_H_
