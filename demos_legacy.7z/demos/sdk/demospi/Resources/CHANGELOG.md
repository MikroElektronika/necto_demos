# Changelog

## Version 3.0.0

- New structure

## Version 2.0.0.5

- Added recursive inclusion for linker scripts and startup files into the CMakeLists.txt.

## Version 2.0.0.4

- Updated the list of supported compilers.

## Version 2.0.0.3

- Fixed function `application_task` to return adequate value in case of success as well.

## Version 2.0.0.2

- Added preinit.

## Version 2.0.0.0

- Initial release
