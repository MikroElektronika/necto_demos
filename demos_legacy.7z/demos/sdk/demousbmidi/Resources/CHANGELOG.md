# Changelog

## Version 3.0.0

- New structure

## Version 2.0.0.7

- Added recursive inclusion for linker scripts and startup files into the CMakeLists.txt.

## Version 2.0.0.6

- Updated the list of supported architectures.

## Version 2.0.0.5

- Updated the list of supported compilers.

## Version 2.0.0.4

- Added preinit.

## Version 2.0.0.2

- Initial release
