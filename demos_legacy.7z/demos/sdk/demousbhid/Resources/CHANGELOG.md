# Changelog

## Version 3.0.0

- New structure

## Version 2.0.0.9

- Added recursive inclusion for linker scripts and startup files into the CMakeLists.txt.

## Version 2.0.0.8

- Updated the list of supported architectures.

## Version 2.0.0.7

- Updated the list of supported compilers.

## Version 2.0.0.6

- Added preinit.

## Version 2.0.0.4

- Initial release
