# Changelog

## Version 3.0.0

- New structure

## Version 2.0.0.30

- Added recursive inclusion for linker scripts and startup files into the CMakeLists.txt.

## Version 2.0.0.29

- Updated the list of supported compilers.

## Version 2.0.0.28

- Added preinit.

## Version 2.0.0.24

- Added dsPIC support (through mikroSDK)

## Version 2.0.0.0

- Initial release
