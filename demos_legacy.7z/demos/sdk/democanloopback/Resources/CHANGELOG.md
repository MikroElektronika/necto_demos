# Changelog

## Version 3.0.0

- New structure

## Version 2.0.0.6

- Removed definition of FILTER-TO-FIFO number and filter bank and replaced it with the default values from SDK for newer SDKs.
- Removed baud rate setup and left it to be set to default value for newer SDKs.

## Version 2.0.0.5

- Added recursive inclusion for linker scripts and startup files into the CMakeLists.txt.

## Version 2.0.0.4

- Updated the list of supported compilers.

## Version 2.0.0.3

- Added preinit.

## Version 2.0.0.0

- Initial release
