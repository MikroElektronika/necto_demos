# Changelog

## Version 3.0.0

- New structure

## Version 2.0.0.18

- Added recursive inclusion for linker scripts and startup files into the CMakeLists.txt.

## Version 2.0.0.17

- Updated the list of supported compilers.

## Version 2.0.0.16

- Added preinit.

## Version 2.0.0.12

- Added dsPIC support (through mikroSDK)

## Version 2.0.0.0

- Initial release
